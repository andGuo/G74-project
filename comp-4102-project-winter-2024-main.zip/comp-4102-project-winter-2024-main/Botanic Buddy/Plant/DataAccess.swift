import SQLite
import Foundation

public struct Plant {
    public let name: String
    public let cycle: String
    public let watering: String
    public let propagation: String
    public let hardinessZone: String
    public let flowers: String
    public let sun: String
    public let soil: String
    public let maintenance: String
    public let growthRate: String
}

class DataAccess {
    var db: Connection?
    
    init() {
        do {
            let dbPath = Bundle.main.path(forResource: "plants", ofType: "sqlite3")!
            db = try Connection(dbPath, readonly: true)
        } catch {
            assertionFailure("Error opening database: \(error)")
        }
    }
    
    func getPlantData(byName name: String) -> Plant? {
        guard let db = db else {
            assertionFailure("Database connection not established")
            return nil
        }
        
        let plants = Table("plants")
        let query = plants.filter(Expression<String>("name") == name)
        
        do {
            if let row = try db.pluck(query) {
                return Plant(name: row[Expression<String>("name")],
                             cycle: row[Expression<String>("cycle")],
                             watering: row[Expression<String>("watering")],
                             propagation: row[Expression<String>("propagation")],
                             hardinessZone: row[Expression<String>("hardiness_zone")],
                             flowers: row[Expression<String>("flowers")],
                             sun: row[Expression<String>("sun")],
                             soil: row[Expression<String>("soil")],
                             maintenance: row[Expression<String>("maintenance")],
                             growthRate: row[Expression<String>("growth_rate")])
            } else {
                print("Plant with name \(name) not found")
                return nil
            }
        } catch {
            print("Error fetching plant: \(error)")
            return nil
        }
    }
}
