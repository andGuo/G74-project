import UIKit
import CoreML
import Vision
import SceneKit

class ObjectDetectionService {
    private let config = MLModelConfiguration()
    private var mlModel: VNCoreMLModel?
    private var completion: ((Result<Response, Error>) -> Void)?
    
    init() {
        config.setValue(1, forKey: "experimentalMLE5EngineUsage")
        loadModel()
    }
    
    private func loadModel() {
        do {
            mlModel = try VNCoreMLModel(for: botanic_buddy_YOLOv8_nms_best(configuration: config).model)
        } catch {
            print("Error loading model: \(error)")
        }
    }
    
    // Performs object detection on the given request.
    func detect(on request: Request, completion: @escaping (Result<Response, Error>) -> Void) {
        self.completion = completion
        
        guard let model = mlModel else {
            completion(.failure(RecognitionError.unableToInitializeCoreMLModel))
            return
        }
        
        let coreMLRequest = VNCoreMLRequest(model: model, completionHandler: coreMlRequestHandler)
        let orientation = CGImagePropertyOrientation(rawValue:  UIDevice.current.exifOrientation) ?? .up
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: request.pixelBuffer, orientation: orientation)
        
        do {
            try imageRequestHandler.perform([coreMLRequest])
        } catch {
            complete(.failure(error))
        }
    }
    
    // Handles the result from the Core ML request.
    private func coreMlRequestHandler(_ request: VNRequest?, error: Error?) {
        if let error = error {
            complete(.failure(error))
            return
        }
        
        print("Here")
        
        guard let results = request?.results as? [VNRecognizedObjectObservation],
              let result = results.first(where: { $0.confidence > 0.6 }),
              let classification = result.labels.first else {
                complete(.failure(RecognitionError.resultIsEmpty))
                return
            }
        
        print(classification)
        
        let response = Response(boundingBox: result.boundingBox, classification: classification.identifier)
        complete(.success(response))
    }
    
    // Completes the detection with the given result.
    private func complete(_ result: Result<Response, Error>) {
        DispatchQueue.main.async {
            self.completion?(result)
            self.completion = nil
        }
    }
}

extension ObjectDetectionService {
    enum RecognitionError: Error {
        case unableToInitializeCoreMLModel, resultIsEmpty, lowConfidence
    }

    struct Request {
        let pixelBuffer: CVPixelBuffer
    }
    
    struct Response {
        let boundingBox: CGRect
        let classification: String
    }
}
