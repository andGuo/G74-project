import Foundation

class Throttler {
    private var workItem: DispatchWorkItem = DispatchWorkItem { }
    private var previousRun: Date = Date.distantPast
    private let queue: DispatchQueue
    private let minimumDelay: TimeInterval

    // Initializes a new Throttler.
    init(minimumDelay: TimeInterval, queue: DispatchQueue = .global(qos: .userInteractive)) {
        self.minimumDelay = minimumDelay
        self.queue = queue
    }
    
    // Executes the block of code only if the specified `minimumDelay` has passed since the last execution.
    func throttle(_ block: @escaping () -> Void) {
        workItem.cancel()

        workItem = DispatchWorkItem { [weak self] in
            self?.previousRun = Date()
            block()
        }

        // Calculate the delay based on the time elapsed since the last run.
        let delay = previousRun.timeIntervalSinceNow > minimumDelay ? 0 : minimumDelay
        
        queue.asyncAfter(deadline: .now() + delay, execute: workItem)
    }
}
