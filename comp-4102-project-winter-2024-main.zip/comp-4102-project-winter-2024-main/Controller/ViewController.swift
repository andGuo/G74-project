import UIKit
import Vision
import ARKit


class ViewController: UIViewController {
    var objectDetectionService = ObjectDetectionService()
    let throttler = Throttler(minimumDelay: 0.5, queue: .global(qos: .userInteractive))
    var isLoopShouldContinue = true
    var lastLocation: SCNVector3?
    let db = DataAccess()
    
    @IBOutlet var sceneView: ARSCNView!
    @IBOutlet weak var sessionInfoLabel: UILabel!
    
    @objc private var whiteFrameView: UIView!
    private var plantName: UILabel!
    private var plantCycle: UILabel!
    private var plantWatering: UILabel!
    private var plantFlowers: UILabel!
    private var plantSun: UILabel!
    private var plantGrowth: UILabel!
    private var plantPropagation: UILabel!
    private var plantMaintenance: UILabel!
    private var plantSoil: UILabel!
    private var plantHardinessZone: UILabel!
    private var hideButton: UIButton!
    
    private var mossyGreen: UIColor = UIColor(red: 0.33, green: 0.42, blue: 0.18, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sceneView.delegate = self
        sceneView.session.delegate = self
        sceneView.scene = SCNScene()
        
        sceneView.autoenablesDefaultLighting = true
        
        setupWhiteFrame()
        setUpLabels()
        setupHideButton()
    }
    
    private func setUpLabels() {
        plantName = UILabel()
        plantName.textColor = UIColor.black.withAlphaComponent(0.8)

        if let descriptor = UIFont.systemFont(ofSize: 24, weight: .bold).fontDescriptor.withDesign(.rounded) {
            plantName.font = UIFont(descriptor: descriptor, size: 24)
        } else {
            plantName.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        }
        
        plantCycle = UILabel()
        plantCycle.textColor = mossyGreen
        plantCycle.font = UIFont.preferredFont(forTextStyle: .caption1)
        
        plantWatering = UILabel()
        plantSun = UILabel()
        plantFlowers = UILabel()
        plantGrowth = UILabel()
        plantPropagation = UILabel()
        plantMaintenance = UILabel()
        plantSoil = UILabel()
        plantHardinessZone = UILabel()
        
        plantFlowers.numberOfLines = 0
        plantPropagation.numberOfLines = 0

        plantName.translatesAutoresizingMaskIntoConstraints = false
        plantCycle.translatesAutoresizingMaskIntoConstraints = false
        plantWatering.translatesAutoresizingMaskIntoConstraints = false
        plantSun.translatesAutoresizingMaskIntoConstraints = false
        plantFlowers.translatesAutoresizingMaskIntoConstraints = false
        plantGrowth.translatesAutoresizingMaskIntoConstraints = false
        plantPropagation.translatesAutoresizingMaskIntoConstraints = false
        plantMaintenance.translatesAutoresizingMaskIntoConstraints = false
        plantSoil.translatesAutoresizingMaskIntoConstraints = false
        plantHardinessZone.translatesAutoresizingMaskIntoConstraints = false
        
        whiteFrameView.addSubview(plantName)
        whiteFrameView.addSubview(plantCycle)
        whiteFrameView.addSubview(plantWatering)
        whiteFrameView.addSubview(plantSun)
        whiteFrameView.addSubview(plantFlowers)
        whiteFrameView.addSubview(plantGrowth)
        whiteFrameView.addSubview(plantPropagation)
        whiteFrameView.addSubview(plantMaintenance)
        whiteFrameView.addSubview(plantSoil)
        whiteFrameView.addSubview(plantHardinessZone)
        
        let padding: CGFloat = 20

        NSLayoutConstraint.activate([
            plantName.topAnchor.constraint(equalTo: whiteFrameView.topAnchor, constant: padding),
            plantName.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantName.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantCycle.topAnchor.constraint(equalTo: plantName.bottomAnchor, constant: 10),
            plantCycle.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantCycle.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantWatering.topAnchor.constraint(equalTo: plantCycle.bottomAnchor, constant: 10),
            plantWatering.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantWatering.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantGrowth.leadingAnchor.constraint(equalTo: plantWatering.trailingAnchor, constant: 8),
            plantGrowth.centerYAnchor.constraint(equalTo: plantWatering.centerYAnchor),
            plantGrowth.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantSun.topAnchor.constraint(equalTo: plantWatering.bottomAnchor, constant: 10),
            plantSun.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantSun.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantFlowers.topAnchor.constraint(equalTo: plantSun.bottomAnchor, constant: 10),
            plantFlowers.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantFlowers.widthAnchor.constraint(equalToConstant: 330),
            plantFlowers.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantMaintenance.topAnchor.constraint(equalTo: plantFlowers.bottomAnchor, constant: 10),
            plantMaintenance.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantMaintenance.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantSoil.topAnchor.constraint(equalTo: plantMaintenance.bottomAnchor, constant: 10),
            plantSoil.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantSoil.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantHardinessZone.topAnchor.constraint(equalTo: plantSoil.bottomAnchor, constant: 10),
            plantHardinessZone.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantHardinessZone.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            
            plantPropagation.topAnchor.constraint(equalTo: plantHardinessZone.bottomAnchor, constant: 10),
            plantPropagation.leadingAnchor.constraint(equalTo: whiteFrameView.leadingAnchor, constant: padding),
            plantPropagation.widthAnchor.constraint(equalToConstant: 330),
            plantPropagation.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -padding),
            plantPropagation.bottomAnchor.constraint(equalTo: whiteFrameView.bottomAnchor, constant: -padding)
        ])
    }
    
    private func setupHideButton() {
        hideButton = UIButton(type: .system)
        
        let image = UIImage(systemName: "xmark")
        hideButton.setImage(image, for: .normal)
        hideButton.tintColor = UIColor.white

        hideButton.backgroundColor = .red
        hideButton.layer.cornerRadius = 10
        hideButton.addTarget(self, action: #selector(hideWhiteFrameView), for: .touchUpInside)

        whiteFrameView.addSubview(hideButton)
        hideButton.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            hideButton.topAnchor.constraint(equalTo: whiteFrameView.topAnchor, constant: 20),
            hideButton.trailingAnchor.constraint(equalTo: whiteFrameView.trailingAnchor, constant: -20),
            hideButton.widthAnchor.constraint(equalToConstant: 40),
            hideButton.heightAnchor.constraint(equalToConstant: 40)
        ])
    }
    
    @objc func hideWhiteFrameView() {
        UIView.animate(withDuration: 0.5, animations: {
            self.whiteFrameView.alpha = 0
        }) { _ in
            self.whiteFrameView.isHidden = true
        }
    }
    
    private func setupWhiteFrame() {
        whiteFrameView = UIView()
        whiteFrameView.backgroundColor = .white.withAlphaComponent(0.35)
        whiteFrameView.layer.cornerRadius = 30
        whiteFrameView.layer.shadowColor = UIColor.black.cgColor
        whiteFrameView.layer.shadowOpacity = 0.1
        whiteFrameView.layer.shadowOffset = CGSize(width: 0, height: 10)
        whiteFrameView.layer.shadowRadius = 10

        let blurEffect = UIBlurEffect(style: .regular)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = whiteFrameView.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        blurEffectView.layer.cornerRadius = 30
        blurEffectView.layer.masksToBounds = true

        whiteFrameView.addSubview(blurEffectView)

        whiteFrameView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(whiteFrameView)

        let bottomPadding: CGFloat = 30
        whiteFrameView.isHidden = true

        NSLayoutConstraint.activate([
            whiteFrameView.widthAnchor.constraint(equalToConstant: 370),
            whiteFrameView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            whiteFrameView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -bottomPadding)
        ])
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        startSession()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        stopSession()
    }
    
    private func startSession(resetTracking: Bool = false) {
        guard ARWorldTrackingConfiguration.isSupported else {
            assertionFailure("ARKit is not supported")
            return
        }
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        
        if resetTracking {
            sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
        } else {
            sceneView.session.run(configuration)
        }
    }
    
    func stopSession() {
        sceneView.session.pause()
    }
    
    func loopObjectDetection() {
        throttler.throttle { [weak self] in
            guard let self = self else { return }
            
            if self.isLoopShouldContinue {
                self.performDetection()
            }
            self.loopObjectDetection()
        }
    }
    
    func performDetection() {
        guard let pixelBuffer = sceneView.session.currentFrame?.capturedImage else { return }
        
        objectDetectionService.detect(on: .init(pixelBuffer: pixelBuffer)) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let response):
                if (self.whiteFrameView.isHidden == true) {
                    self.whiteFrameView.isHidden = false
                    self.whiteFrameView.alpha = 0
                    UIView.animate(withDuration: 0.5) {
                        self.whiteFrameView.alpha = 1
                    }
                }
                self.addAnnotation(text: response.classification)
                
            case .failure(let error):
                break
            }
        }
    }
    
    private func formatLabel(before: String, after: String, image: String, color: UIColor) -> NSMutableAttributedString {
        let attributedString = NSMutableAttributedString(string: before)
        
        let attachment = NSTextAttachment()
        
        if let image = UIImage(systemName: image)?.withTintColor(color, renderingMode: .alwaysOriginal) {
            attachment.image = image
            attachment.bounds = CGRect(x: 0, y: (plantWatering.font.capHeight - image.size.height).rounded() / 2, width: image.size.width, height: image.size.height)
        }
        
        attributedString.append(NSAttributedString(attachment: attachment))
        attributedString.append(NSAttributedString(string: ": "+after))
        
        return attributedString
    }
    
    func addAnnotation(text: String) {
        let plantData = db.getPlantData(byName: text)!
        
        plantName.text = plantData.name.replacingOccurrences(of: "-", with: " ").capitalized
        plantCycle.text = plantData.cycle.uppercased()

        plantWatering.attributedText = formatLabel(before: "Water ", after: plantData.watering, image: "drop", color: UIColor(red: 52.0/255.0, green: 149.0/255.0, blue: 235.0/255.0, alpha: 0.8))
        plantSun.attributedText = formatLabel(before: "Sun ", after: plantData.sun, image: "sun.max", color: UIColor(red: 255.0/255.0, green: 165.0/255.0, blue: 0.0/255.0, alpha: 1.0))
        plantFlowers.attributedText = formatLabel(before: "Flowers ", after: plantData.flowers, image: "camera.macro", color: UIColor(red: 240.0/255.0, green: 110.0/255.0, blue: 164.0/255.0, alpha: 0.8))
        plantGrowth.attributedText = formatLabel(before: "|  Growth ", after: plantData.growthRate, image: "heat.waves", color: mossyGreen)
        plantPropagation.attributedText = formatLabel(before: "Propagation Methods ", after: plantData.propagation, image: "leaf", color: mossyGreen)
        plantMaintenance.attributedText = formatLabel(before: "Maintenance ", after: plantData.maintenance, image: "hand.thumbsup", color: UIColor(red: 186.0/255.0, green: 148.0/255.0, blue: 242.0/255.0, alpha: 0.8))
        plantSoil.attributedText = formatLabel(before: "Soil ", after: plantData.soil, image: "aqi.medium", color: UIColor(red: 97.0/255.0, green: 65.0/255.0, blue: 6.0/255.0, alpha: 0.8))
        plantHardinessZone.attributedText = formatLabel(before: "Hardiness Zone ", after: plantData.hardinessZone, image: "globe.europe.africa", color: UIColor(red: 52.0/255.0, green: 149.0/255.0, blue: 235.0/255.0, alpha: 0.8))
    }
    
    private func onSessionUpdate(for frame: ARFrame, with trackingState: ARCamera.TrackingState) {
            let message = getMessageForTrackingState(trackingState, with: frame)

            updateSessionInfoLabel(with: message)
            manageObjectDetectionLoop(shouldContinue: trackingState == .normal && !frame.anchors.isEmpty)
        }

        private func getMessageForTrackingState(_ trackingState: ARCamera.TrackingState, with frame: ARFrame) -> String {
            switch trackingState {
            case .normal where frame.anchors.isEmpty:
                return "Move the device around to detect horizontal and vertical surfaces."
            case .normal:
                // Tracking is normal, no message needed, can proceed with object detection
                return ""
            case .notAvailable:
                return "Tracking unavailable."
            case .limited(.excessiveMotion):
                return "Tracking limited - Move the device more slowly."
            case .limited(.insufficientFeatures):
                return "Tracking limited - Point the device at an area with visible surface detail, or improve lighting conditions."
            case .limited(.initializing):
                return "Initializing AR session."
            default:
                return "Tracking state unknown."
            }
        }

        private func updateSessionInfoLabel(with message: String) {
            sessionInfoLabel.text = message
            sessionInfoLabel.isHidden = message.isEmpty
        }

        private func manageObjectDetectionLoop(shouldContinue: Bool) {
            isLoopShouldContinue = shouldContinue
            if shouldContinue {
                loopObjectDetection()
            }
        }
    }

    extension ViewController: ARSessionDelegate {
        func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
            updateTrackingState(from: session, camera: camera)
        }
        
        func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
            updateTrackingState(from: session)
        }
        
        func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
            updateTrackingState(from: session)
        }
        
        func session(_ session: ARSession, didUpdate frame: ARFrame) {
            updateCameraPosition(from: frame)
        }

        func sessionWasInterrupted(_ session: ARSession) {
            sessionInfoLabel.text = "Session was interrupted"
        }
        
        func sessionInterruptionEnded(_ session: ARSession) {
            sessionInfoLabel.text = "Session interruption ended"
            startSession(resetTracking: true)
        }
        
        func session(_ session: ARSession, didFailWithError error: Error) {
            sessionInfoLabel.text = "Session error: \(error.localizedDescription)"
        }

        private func updateTrackingState(from session: ARSession, camera: ARCamera? = nil) {
            guard let frame = session.currentFrame else { return }
            let trackingState = camera?.trackingState ?? frame.camera.trackingState
            onSessionUpdate(for: frame, with: trackingState)
        }

        private func updateCameraPosition(from frame: ARFrame) {
            let transform = SCNMatrix4(frame.camera.transform)
            let orientation = SCNVector3(-transform.m31, -transform.m32, transform.m33)
            let location = SCNVector3(transform.m41, transform.m42, transform.m43)
            let currentPositionOfCamera = orientation + location
            
            if let lastLocation = lastLocation {
                let speed = (lastLocation - currentPositionOfCamera).length()
                isLoopShouldContinue = speed < 0.0025
            }
            lastLocation = currentPositionOfCamera
        }
    }

    extension ViewController: ARSCNViewDelegate { }
